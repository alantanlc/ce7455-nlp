Question 1: 2 day
Question 2: 7 days
